CREATE TABLE daftarBuku
(	
	id CHAR(50) PRIMARY KEY, 
    judul VARCHAR(50), 
    penulis VARCHAR(50), 
    penerbit VARCHAR(50), 
    tahunTerbit DATE, 
    kategori VARCHAR(50)
);

